/* C backend starter: preserves TAC as comments for inspection. */
#include <stdio.h>
int main(void) {
    FILE *in=fopen("optimized_tac.txt","r"), *out=fopen("target_code.txt","w");
    int c;
    if(!in){perror("optimized_tac.txt");return 1;}
    if(!out){perror("target_code.txt");fclose(in);return 1;}
    fputs("; Starter backend output; replace TAC lines with target instructions.\n",out);
    while((c=fgetc(in))!=EOF) fputc(c,out);
    fclose(in); fclose(out);
    puts("target_code.txt generated. See README for target-instruction mapping.");
    return 0;
}
