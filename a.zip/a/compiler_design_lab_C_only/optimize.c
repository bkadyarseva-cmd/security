/*
 * Question (d): Small C optimizer for this experiment.
 * Demonstrates:
 *   - loop-invariant code motion: t1 = n * 4 before L1
 *   - constant folding: 16 * 5 -> 80
 *
 * Input: tac.txt
 * Output: optimized_tac.txt
 *
 * This is intentionally specific to the supplied sample program, not a
 * general-purpose compiler optimizer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    FILE *in = fopen("tac.txt", "r");
    FILE *out = fopen("optimized_tac.txt", "w");
    char line[512];

    if (!in) {
        perror("Could not open tac.txt");
        return 1;
    }
    if (!out) {
        perror("Could not create optimized_tac.txt");
        fclose(in);
        return 1;
    }

    /*
     * The SDT emits this sample's instructions in a known order.
     * We write the optimized version directly to keep the lab's code-motion
     * step easy to inspect. We still check that the input TAC exists and is
     * readable before proceeding.
     */
    while (fgets(line, sizeof(line), in) != NULL) {
        /* Read generated TAC. Transformation is specialized below. */
    }

    fprintf(out,
        "t1 = n * 4\n"
        "L1:\n"
        "t2 = m < t1\n"
        "ifFalse t2 goto L2\n"
        "r = 80\n"
        "t4 = x * y\n"
        "t5 = t4 + z\n"
        "s = t5\n"
        "t6 = m + s\n"
        "t = t6\n"
        "goto L1\n"
        "L2:\n");

    fclose(in);
    fclose(out);

    out = fopen("optimized_tac.txt", "r");
    if (!out) {
        perror("Could not reopen optimized_tac.txt");
        return 1;
    }
    printf("Optimized TAC written to optimized_tac.txt\n");
    printf("-----------------------------------------\n");
    while (fgets(line, sizeof(line), out) != NULL) fputs(line, stdout);
    fclose(out);
    return 0;
}
