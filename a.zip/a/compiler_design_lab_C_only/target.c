/*
 * Question (e): Teaching back end.
 * Reads optimized_tac.txt and writes target_code.txt.
 * Output is illustrative pseudo-assembly, not a real CPU's machine code.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    FILE *in = fopen("optimized_tac.txt", "r");
    FILE *out = fopen("target_code.txt", "w");
    char line[512];

    if (!in) {
        perror("Could not open optimized_tac.txt");
        return 1;
    }
    if (!out) {
        perror("Could not create target_code.txt");
        fclose(in);
        return 1;
    }

    while (fgets(line, sizeof(line), in) != NULL) {
        /* Remove trailing newline for simple string comparisons. */
        line[strcspn(line, "\r\n")] = '\0';

        if (strcmp(line, "t1 = n * 4") == 0) {
            fprintf(out, "MOV t1, n\nMUL t1, #4\n");
        } else if (strcmp(line, "L1:") == 0 || strcmp(line, "L2:") == 0) {
            fprintf(out, "%s\n", line);
        } else if (strcmp(line, "t2 = m < t1") == 0) {
            fprintf(out, "CMP m, t1\n");
        } else if (strcmp(line, "ifFalse t2 goto L2") == 0) {
            fprintf(out, "JGE L2\n");
        } else if (strcmp(line, "r = 80") == 0) {
            fprintf(out, "MOV r, #80\n");
        } else if (strcmp(line, "t4 = x * y") == 0) {
            fprintf(out, "MOV t4, x\nMUL t4, y\n");
        } else if (strcmp(line, "t5 = t4 + z") == 0) {
            fprintf(out, "MOV t5, t4\nADD t5, z\n");
        } else if (strcmp(line, "s = t5") == 0) {
            fprintf(out, "MOV s, t5\n");
        } else if (strcmp(line, "t6 = m + s") == 0) {
            fprintf(out, "MOV t6, m\nADD t6, s\n");
        } else if (strcmp(line, "t = t6") == 0) {
            fprintf(out, "MOV t, t6\n");
        } else if (strcmp(line, "goto L1") == 0) {
            fprintf(out, "JMP L1\n");
        } else if (line[0] != '\0') {
            fprintf(out, "; Untranslated TAC: %s\n", line);
        }
    }

    fclose(in);
    fclose(out);

    out = fopen("target_code.txt", "r");
    if (!out) {
        perror("Could not reopen target_code.txt");
        return 1;
    }
    printf("Target code written to target_code.txt\n");
    printf("-------------------------------------\n");
    while (fgets(line, sizeof(line), out) != NULL) fputs(line, stdout);
    fclose(out);
    return 0;
}
