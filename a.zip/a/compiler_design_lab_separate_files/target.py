#!/usr/bin/env python3
"""Translate optimized TAC to illustrative pseudo-assembly (not real machine code)."""
import re
from pathlib import Path

src = Path("optimized_tac.txt")
out = Path("target_code.txt")
if not src.exists():
    raise SystemExit("Missing optimized_tac.txt. First run: python3 optimize.py")
lines = [x.strip() for x in src.read_text().splitlines() if x.strip()]
result = []

for line in lines:
    if line.endswith(":"):
        result.append(line)
        continue
    m = re.fullmatch(r"goto\s+(L\d+)", line)
    if m:
        result.append(f"JMP {m.group(1)}")
        continue
    m = re.fullmatch(r"ifFalse\s+(t\d+)\s+goto\s+(L\d+)", line)
    if m:
        temp, label = m.groups()
        cond = next((x for x in lines if re.match(re.escape(temp) + r"\s*=\s*.*<.*", x)), None)
        if cond:
            c = re.fullmatch(re.escape(temp) + r"\s*=\s*(\S+)\s*<\s*(\S+)", cond)
            if c:
                left, right = c.groups()
                result.extend([f"CMP {left}, {right}", f"JGE {label}"])
            else:
                result.append(f"JZ {temp}, {label}")
        else:
            result.append(f"JZ {temp}, {label}")
        continue
    if re.fullmatch(r"t\d+\s*=\s*\S+\s*<\s*\S+", line):
        continue
    m = re.fullmatch(r"([A-Za-z_]\w*)\s*=\s*(-?\d+)", line)
    if m:
        result.append(f"MOV {m.group(1)}, #{m.group(2)}")
        continue
    m = re.fullmatch(r"([A-Za-z_]\w*|t\d+)\s*=\s*([A-Za-z_]\w*|t\d+)\s*([+*])\s*([A-Za-z_]\w*|t\d+|-?\d+)", line)
    if m:
        dest, left, op, right = m.groups()
        result.extend([f"MOV {dest}, {left}", f"{'ADD' if op == '+' else 'MUL'} {dest}, {right}"])
        continue
    m = re.fullmatch(r"([A-Za-z_]\w*)\s*=\s*([A-Za-z_]\w*|t\d+)", line)
    if m:
        result.append(f"MOV {m.group(1)}, {m.group(2)}")
        continue
    result.append(f"; Untranslated TAC: {line}")

out.write_text("\n".join(result) + "\n")
print("Target code written to target_code.txt")
print("-------------------------------------")
print(out.read_text(), end="")
