%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
int temp_no=0;
char *newtemp(void){ char b[24]; sprintf(b,"t%d",++temp_no); return strdup(b); }
%}
%union { int num; char *str; }
%token WHILE IF ELSE FOR DO LBRACE RBRACE LPAREN RPAREN SEMICOLON ASSIGN LT PLUS MUL INVALID
%token <num> NUMBER
%token <str> ID
%type <str> expr
%left PLUS
%left MUL
%%
program: ID ASSIGN expr SEMICOLON { printf("%s = %s\n",$1,$3); printf("Syntax is correct.\n"); } ;\n
expr: expr PLUS expr { char *t=newtemp(); printf("%s = %s + %s\n",t,$1,$3); $$=t; }
    | expr MUL expr { char *t=newtemp(); printf("%s = %s * %s\n",t,$1,$3); $$=t; }
    | LPAREN expr RPAREN { $$=$2; }
    | ID { $$=$1; }
    | NUMBER { char b[24]; sprintf(b,"%d",$1); $$=strdup(b); }
    ;

%%
void yyerror(const char *s){ fprintf(stderr,"Syntax error: %s\n",s); }
int main(void){ printf("Three-address code (TAC):\n"); return yyparse() ? 1 : 0; }
