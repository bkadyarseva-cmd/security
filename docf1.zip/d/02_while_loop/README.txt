COMPILER DESIGN LAB — WHILE LOOP
====================================

SAMPLE INPUT
------------
while (m < n * 4)\n{\n    r = 16 * 5;\n    s = x * y + z;\n    t = m + s;\n}\n

FILES
-----
lexer.l       LEX token rules (a)
parser.y      YACC grammar and SDT actions (b, c)
input.txt     Sample program
optimize.c    C optimization explanation/demo (d)
target.c      C target-like output demo (e)
README.txt    Execution steps and concepts

EXECUTION (run in this folder)
------------------------------
1. lex lexer.l
2. yacc -d parser.y
3. gcc y.tab.c lex.yy.c -o parser -lfl
4. ./parser < input.txt
5. gcc optimize.c -o optimize
6. ./optimize
7. gcc target.c -o target
8. ./target

QUESTION MAPPING
----------------
(a) lexer.l identifies keywords, identifiers, numbers, operators, and punctuation.
(b) parser.y checks whether the sample follows the grammar.
(c) YACC semantic actions print TAC using temporary variables and labels.
(d) Optimization concept: Move `n * 4` before the loop only if n is not changed in the loop body. Constant-fold `16 * 5` to 80.
(e) target.c prints illustrative instructions such as MOV, MUL, ADD, CMP, and jumps.
(f) Run all steps in the order shown above.

IMPORTANT LIMITATIONS
---------------------
These are beginner practice templates, not a complete general-purpose compiler.
The parser grammar is restricted to the sample shape. The optimize.c file prints
the optimization idea, rather than reading and transforming TAC automatically.
The target.c file prints illustrative target-like output, not real machine code.
Some sample grammars are simplified for learning; always test and adjust the
grammar if your instructor's input format differs.

CONCEPTS TO REMEMBER
--------------------
LEX: characters -> tokens
YACC: tokens -> syntax checking
SDT: grammar actions -> three-address code
Optimization: improve intermediate code
Backend: translate optimized code to target instructions
