COMPILER DESIGN LAB — ALL QUESTION TYPES\n\n'
'Folders: 01_assignment, 02_while_loop, 03_if_else, 04_for_loop, 05_do_while.\n'
'Each folder contains lexer.l, parser.y, input.txt, optimize.c, target.c and README.txt.\n'
'Read the README inside each folder for exact Linux execution commands.\n'
'These are learning templates with sample-specific grammars and demonstration optimizer/backend stages.\n