Experiment 8(B): File Integrity Monitoring System

Folder contents:
- file_monitor.py: Main Python program
- checksums.json: Persistent checksum record (starts empty)
- test_files/sample1.txt and sample2.txt: Example files to monitor

Run:
1. Open a terminal in this folder.
2. Run: python file_monitor.py
3. Enter: test_files

First run reports New File; a second run without changes reports Not Modified.
Edit a sample file to test Modified. Delete a sample file to test Missing File.
