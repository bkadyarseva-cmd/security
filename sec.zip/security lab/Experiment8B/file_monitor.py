import hashlib
import json
from pathlib import Path

RECORD_FILE = Path("checksums.json")


# Calculate MD5 checksum
def md5_file(file_path):
    with open(file_path, "rb") as file:
        return hashlib.md5(file.read()).hexdigest()


# Load stored checksums
def load_checksums():
    if not RECORD_FILE.exists():
        return {}

    with open(RECORD_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


# Save checksums to JSON
def save_checksums(checksums):
    with open(RECORD_FILE, "w", encoding="utf-8") as file:
        json.dump(checksums, file, indent=4)


# Monitor files
def monitor_files():
    folder = Path(input("Enter the directory to monitor: "))

    if not folder.is_dir():
        print("Error: Directory does not exist.")
        return

    try:
        stored = load_checksums()
    except (OSError, json.JSONDecodeError):
        print("Error reading checksum record.")
        return

    current = {}

    # Calculate checksums of current files
    for path in folder.iterdir():
        if path.is_file():
            try:
                current[path.name] = md5_file(path)
            except OSError as error:
                print("Cannot read", path.name, ":", error)

    print("\n--- File Integrity Report ---")

    # Compare current and stored checksums
    for filename, checksum in current.items():
        if filename not in stored:
            print(filename, "-> New File")
        elif stored[filename] == checksum:
            print(filename, "-> Not Modified")
        else:
            print(filename, "-> Modified")

    # Detect missing files
    for filename in stored:
        if filename not in current:
            print(filename, "-> Missing File")

    # Update checksum record
    save_checksums(current)
    print("\nChecksum record updated successfully.")


if __name__ == "__main__":
    monitor_files()
