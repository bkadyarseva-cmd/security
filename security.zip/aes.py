from Crypto.Cipher import AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Random import get_random_bytes

text=input("enter the Text : ")
key=input("Enter the key ").encode()

cipher=AES.new(key,AES.MODE_ECB)

ct1=cipher.encrypt(pad(text.encode(),16))
print(ct1.hex())

decipher=AES.new(key,AES.MODE_ECB)

plain=unpad(decipher.decrypt(ct1),16).decode()
print("ECB decoded : ",plain)



print("CBC ")
iv=get_random_bytes(16)
cipher=AES.new(key,AES.MODE_CBC,iv=iv)

ct1=cipher.encrypt(pad(text.encode(),16))
print(ct1.hex())

decipher=AES.new(key,AES.MODE_CBC,iv=iv)

plain=unpad(decipher.decrypt(ct1),16).decode()
print("CBC decoded : ",plain)



print("CFB ")
iv=get_random_bytes(16)
cipher=AES.new(key,AES.MODE_CFB,iv=iv,segment_size=64)

ct1=cipher.encrypt(pad(text.encode(),16))
print(ct1.hex())

decipher=AES.new(key,AES.MODE_CFB,iv=iv,segment_size=64)

plain=unpad(decipher.decrypt(ct1),16).decode()
print("CBC decoded : ",plain)




print("OFB ")
iv=get_random_bytes(16)
cipher=AES.new(key,AES.MODE_OFB,iv=iv)

ct1=cipher.encrypt(pad(text.encode(),16))
print(ct1.hex())

decipher=AES.new(key,AES.MODE_OFB,iv=iv)

plain=unpad(decipher.decrypt(ct1),16).decode()
print("CBC decoded : ",plain)


