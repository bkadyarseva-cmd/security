def Encryt(word,key):
    key=key%26
    result=""
    for w in word:
        if w.isupper():
            result+=chr( (ord(w)-ord("A")+key)%26+ord("A"))
        elif w.islower():
            result+=chr((ord(w)-ord("a")+key)%26+ord("a"))
        else:
            result+=w
    return result



def Decrypt(word,key):
    return Encryt(word,-key)




text=input("Enter the text : ")

key=int(input("Enter the Key :  "))

key=key%26

print("The Encrytpted Text is :",Encryt(text,key))

print("The Decrypted Text is :",Decrypt(Encryt(text,key),key))

Ep=Encryt(text,key)
print("The Brute Force Attack : ")

for key in range(1,27):
    print(f"The Decrupted Text with  key {key} is : {Decrypt(Ep,key)}")

    """




def encrypt(message,key):
    key=key%26
    result=""
    count=0
    for w in message:
        if w.isalpha():
            if w.isupper():
                result+=chr((ord(w)-ord('A')+key)%26+ord('A'))
                count+=1
            else:
                result+=chr((ord(w)-ord('a')+key)%26+ord('a'))
                count+=1
        else:
            result+=w

    return result,count

def decrypt(message,key):
    return encrypt(message,-key)

def only_vowles(message,key):
    key=key%26
    result=""
    for w in message:
        if w.isalpha():
            if w.isupper():
                if w in "AEIOU":
                    result+=chr((ord(w)-ord('A')+key)%26+ord('A'))
                else:
                    result+=w

            else :
                if w in "aeiou":
                    result+=chr((ord(w)-ord('a')+key)%26+ord('a'))
                else:
                    result+=w

        else:
            result+=w

    return result
                    



print(encrypt("ABCD12# 4",3))


print(decrypt("DEFG12# 4",3))
            

print(only_vowles("ABCDEFGHIJK!@2345",3))


def encrypt(message,key):
    key=key%26
    result=""
    count=0
    for w in message:
        if w.isalpha():
            if w.isupper():
                result+=chr((ord(w)-ord("A")+key)%26+ord("A"))
                count+=1
            else:
                result+=chr((ord(w)-ord("a")+key)%26+ord("a"))
                count+=1
        else:
            result+=w
    print(result)

def decypt(message,key):
    return encrypt(message,-key)
encrypt(input("Enter the message to encyypt : "),int(input("Enter the key ")))


decypt(input("Enter the message to encyypt : "),int(input("Enter the key ")))

"""