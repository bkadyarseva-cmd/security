from Crypto.Cipher import DES
from Crypto.Util.Padding import pad,unpad
from Crypto.Random import get_random_bytes
import os
text=input("Emter the text to encrypt : ")
key=input("enter the 8byte key : ").encode()

cipher=DES.new(key,DES.MODE_ECB)
ciphertext=cipher.encrypt(pad(text.encode(),8))

print("Key : ",key.decode())
print("Cipher text : ",ciphertext.hex())


print("decryption : ")

plain=unpad(cipher.decrypt(ciphertext),8).decode()
print("Decrypted text : ",plain)



print("CBC mode : ")
iv=get_random_bytes(8)
cipher=DES.new(key,DES.MODE_CBC,iv=iv)

ct=cipher.encrypt(pad(text.encode(),8))
print("Encrypted text  by cbc : ",ct.hex())

cipher=DES.new(key,DES.MODE_CBC,iv=iv)
plain=unpad(cipher.decrypt(ct),8).decode()

print("CDb decrypt : ",plain)




print("CFB : ")
iv=get_random_bytes(8)
cipher=DES.new(key,DES.MODE_CFB,iv=iv,segment_size=64)
ct1=cipher.encrypt(pad(text.encode(),8))
print("CFB encryption : ",ct1.hex())


cipher=DES.new(key,DES.MODE_CFB,iv=iv,segment_size=64)
plain1=unpad(cipher.decrypt(ct1),8).decode()
print("Decyption : ",plain1)


print("OFB : ")

iv=get_random_bytes(8)
cipher=DES.new(key,DES.MODE_OFB,iv=iv)

ct=cipher.encrypt(pad(text.encode(),8))
print("Encrypted text  by ofb : ",ct.hex())

cipher=DES.new(key,DES.MODE_OFB,iv=iv)
plain=unpad(cipher.decrypt(ct),8).decode()

print("OFB decrypt : ",plain)
