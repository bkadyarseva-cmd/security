"""
print ("Diffe Helman Key exchange ")

p=int(input("Enter the Prime Number : "))

g=int(input("Enter the Generator : "))

Ap=int(input("Enter Alice Private Key"))
bp=int(input("Enter Bob  Private Key"))

Apub_key=pow(g,Ap,p)
Bpub_key=pow(g,bp,p)


As=pow(Bpub_key,Ap,p)

Bs=pow(Apub_key,bp,p)

print(As,Bs)


p = int(input("Enter prime number (p): "))
g = int(input("Enter primitive root (g): "))

# Store private keys in order
private = [
    int(input("Alice's private key: ")),
    int(input("Bob's private key: ")),
    int(input("Charlie's private key: "))
]

names = ["Alice", "Bob", "Charlie"]

# Calculate public keys in the same order
public = []

for key in private:
    public.append(pow(g, key, p))

print("\nPublic Keys:")
for i in range(len(names)):
    print(names[i], ":", public[i])

# Calculate shared secret for every pair
print("\nShared Secret Keys:")

for i in range(len(names)):
    for j in range(i + 1, len(names)):
        secret1 = pow(public[j], private[i], p)
        secret2 = pow(public[i], private[j], p)

        print(names[i], "and", names[j], ":", secret1)

        if secret1 == secret2:
            print("Verified")
        else:
            print("Not verified")


"""


p=int(input("Enter the prime number: "))
g=int(input("Enter the primitive root g : "))

ap=int(input("Enter alice pvt key : "))

bp=int(input("Enter BOB pvt key : "))

apb=pow(g,ap,p)

bpb=pow(g,bp,p)

sharedkey_A=pow(bpb,ap,p)
sharedkey_B=pow(apb,bp,p)

print(sharedkey_A,sharedkey_B)