from Crypto.PublicKey import DSA
from Crypto.Signature import DSS
from Crypto.Hash import SHA256

# Generate DSA key pair
key = DSA.generate(2048)
private_key = key
public_key = key.publickey()

# Read the message
message = input("Enter the message: ").encode()

# Generate hash of the message
hash_obj = SHA256.new(message)

# Sign the message using the private key
signer = DSS.new(private_key, 'fips-186-3')
signature = signer.sign(hash_obj)

print("Digital Signature:", signature.hex())

# Verify the signature using the public key
hash_obj = SHA256.new(message)
verifier = DSS.new(public_key, 'fips-186-3')

try:
    verifier.verify(hash_obj, signature)
    print("Signature is valid.")
except ValueError:
    print("Signature is invalid.")


from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

key = RSA.generate(2048)
private_key = key
public_key = key.publickey()

while True:
    print("\n1. Generate Keys")
    print("2. Sign Message")
    print("3. Verify Signature")
    print("4. Tamper Message")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        key = RSA.generate(2048)
        private_key = key
        public_key = key.publickey()
        print("Keys generated!")

    elif choice == "2":
        message = input("Enter message: ")
        digest = SHA256.new(message.encode())
        signature = pkcs1_15.new(private_key).sign(digest)
        print("Digest:", digest.hexdigest())
        print("Signature:", signature.hex())

    elif choice == "3":
        message = input("Enter message to verify: ")
        try:
            pkcs1_15.new(public_key).verify(
                SHA256.new(message.encode()), signature
            )
            print("Valid signature")
        except (ValueError, TypeError):
            print("Invalid signature")

    elif choice == "4":
        message = input("Enter message: ")
        digest = SHA256.new(message.encode())
        signature = pkcs1_15.new(private_key).sign(digest)

        modified = message + "X"

        try:
            pkcs1_15.new(public_key).verify(
                SHA256.new(modified.encode()), signature
            )
            print("Valid signature")
        except (ValueError, TypeError):
            print("Invalid signature: Message altered")

    elif choice == "5":
        break

    else:
        print("Invalid choice")






from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256



pvtkey=RSA.generate(2048)
pubkey=pvtkey.publickey()

message=input("Enter the message : ")

digest=SHA256.new(message.encode())

signature_by_alice=pkcs1_15.new(pvtkey).sign(digest)


m=message
try:
    pkcs1_15.new(pubkey).verify(SHA256.new(m.encode()),signature_by_alice)
    print("VALID")

except(ValueError,TypeError):
    print("Invalid signature")


from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# Step 1: Generate Alice's keys
print("STEP 1: KEY GENERATION")

pvtkey = RSA.generate(2048)
pubkey = pvtkey.publickey()

print("Alice generated RSA public and private keys.")

# Step 2: Alice writes an email
message = input("\nAlice, enter the email message: ")

# Step 3: Alice hashes and signs the message
print("\nSTEP 2: HASHING AND SIGNING")

digest = SHA256.new(message.encode())
print("Message Digest:", digest.hexdigest())

signature = pkcs1_15.new(pvtkey).sign(digest)
print("Alice digitally signed the email.")

# Step 4: Send the email to Bob
print("\nSTEP 3: EMAIL TRANSMISSION")

print("Alice sends the email to Bob.")
print("Email sent successfully!")

received_message = message
received_signature = signature

print("Bob received the email:", received_message)
print("Bob received the digital signature.")

# Step 5: Bob verifies the original email
print("\nSTEP 4: SIGNATURE VERIFICATION")

try:
    pkcs1_15.new(pubkey).verify(
        SHA256.new(received_message.encode()),
        received_signature
    )
    print("Signature is VALID.")
    print("Email is authentic and has not been altered.")

except (ValueError, TypeError):
    print("Signature is INVALID.")

# Step 6: Modify the received email
print("\nSTEP 5: MESSAGE TAMPERING")

modified_message = received_message + "X"

print("Original email:", received_message)
print("Modified email:", modified_message)

# Step 7: Verify the modified email
print("\nSTEP 6: VERIFY MODIFIED EMAIL")

try:
    pkcs1_15.new(pubkey).verify(
        SHA256.new(modified_message.encode()),
        received_signature
    )
    print("Signature is VALID.")

except (ValueError, TypeError):
    print("Signature is INVALID.")
    print("Message was altered during transmission.")

