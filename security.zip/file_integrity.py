
"""
import hashlib
import json
import os
folder = input("Enter folder path to monitor: ")
record = "checksums.json"
if os.path.exists(record):
    with open(record, 'r') as f:
        old = json.load(f)
else:
    old = {}
current = {}

for file in old:
    #path = os.path.join(folder, file)
    if not os.path.exists(file):
        print(file, ": Missing File")
for file in os.listdir(folder):
    path = os.path.join(folder, file)
    if os.path.isfile(path) and file != record:
        with open(path, 'rb') as f:
            checksum = hashlib.md5(f.read()).hexdigest()
        current[file] = checksum
        if file not in old:
            print(file, ": New File")
        elif old[file] == checksum:
            print(file, ": Not Modified")
        else:
            print(file, ": Modified")
with open(record, 'w') as f:
    json.dump(current, f, indent=4)
print("Checksum record updated.")




import hashlib
import os 
import json


record="checksum.json"

folder=input("Enter the folder to montior : ")

if os.path.exists(record):
    with open(record,'r') as f:
        old=json.load(f)
else:
    old={}


current={}

for file in old:
    path=os.path.join(folder,file)
    if  not os.path.exists(path):
        print(file,"Missing")


for file in os.listdir(folder):
    path=os.path.join(folder,file)
    if os.path.isfile(path) and file != record:
        with open (path,"rb") as f:
            checksum=hashlib.sha256(f.read()).hexdigest()
        current[file]=checksum
        if file not in old:
            print(file , "- New file")
        elif old[file]==checksum:
            print(file,"- Not Modified")
        else:
            print(file,"- Modified")

with open(record,"w")as f:
    json.dump(current,f,indent=4)

print("Checksum record updated.")

print("Done")

"""


from Crypto.Hash import MD5
import json 
import os 

folder=input("Enter the folder to montior ")
record="checksum1.json"
if os.path.exists(record):
    with open(record,"r") as f:
        old=json.load(f)
else:
    old={}
current={}

for file in old:
    path=os.path.join(folder,file)
    if not os.path.exists(path):
        print(file , "New file\n")

for file in os.listdir(folder):
    path=os.path.join(folder,file)

    if os.path.isfile(path) and file != record:
        with open(path,"rb") as f:
            checksum=MD5.new(f.read()).hexdigest()
        current[file]=checksum

        if file not in old:
            print(file , "New file")
        elif old[file]==checksum:
            print(file,"Un modified ")
        else:
            print(file," Modified ")

with open(record,"w") as f:
    json.dump(current,f,indent=4)

print("Checksum Updated12 ")
