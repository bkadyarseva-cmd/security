"""
def mod_inverse(a):
    a = a % 26
    for i in range(1, 26):
        if (a * i) % 26 == 1:
            return i
    return -1


def encrypt(text, key):
    text = text.upper().replace(" ", "")

    if len(text) % 2 != 0:
        text += "X"

    cipher = ""

    for i in range(0, len(text), 2):
        p1 = ord(text[i]) - 65
        p2 = ord(text[i + 1]) - 65

        c1 = (key[0][0] * p1 + key[0][1] * p2) % 26
        c2 = (key[1][0] * p1 + key[1][1] * p2) % 26

        cipher += chr(c1 + 65)
        cipher += chr(c2 + 65)

    return cipher


def decrypt(cipher, key):
    det = (key[0][0] * key[1][1] - key[0][1] * key[1][0]) % 26

    inv_det = mod_inverse(det)

    if inv_det == -1:
        print("Key matrix is not invertible.")
        return ""

    inv_key = [
        [(key[1][1] * inv_det) % 26, (-key[0][1] * inv_det) % 26],
        [(-key[1][0] * inv_det) % 26, (key[0][0] * inv_det) % 26]
    ]

    plain = ""

    for i in range(0, len(cipher), 2):
        c1 = ord(cipher[i]) - 65
        c2 = ord(cipher[i + 1]) - 65

        p1 = (inv_key[0][0] * c1 + inv_key[0][1] * c2) % 26
        p2 = (inv_key[1][0] * c1 + inv_key[1][1] * c2) % 26

        plain += chr(p1 + 65)
        plain += chr(p2 + 65)

    return plain


# Main Program
print("Enter 2x2 Key Matrix:")
a = int(input("a11: "))
b = int(input("a12: "))
c = int(input("a21: "))
d = int(input("a22: "))

key = [[a, b], [c, d]]

text = input("Enter Plain Text: ")

cipher = encrypt(text, key)
print("Encrypted Text:", cipher)

plain = decrypt(cipher, key)
print("Decrypted Text:", plain)





def encrypt(text,key):
    text=text.upper().replace(" ","")
    cipher=""

    if len(text)%2!=0:
        text+="X"

    for i in range(0,len(text),2):
        p1=ord(text[i])-65
        p2=ord(text[i+1])-65

        c1=(key[0][0]*p1+key[0][1]*p2)%26
        c2=(key[1][0]*p1+key[1][1]*p2)%26


        cipher+=chr(c1+65)
        cipher+=chr(c2+65)

    return cipher


def inverse_det(a):
    a=a%26

    for i in range(26):
        if (a*i)%26==1:
            return i
    return -1
def decrypt(text,key):
    det=(key[0][0]*key[1][1]-key[0][1]*key[1][0])%26

    inv_det=inverse_det(det)

    if inv_det==-1:
        print("The key is inveraiant ")
        return ""

    inv_key=[[(key[1][1]*inv_det)%26,(-key[0][1]*inv_det)%26],
             [(-key[1][0]*inv_det)%26,(key[0][0]*inv_det)%26]]


    plain=""

    for i in range(0,len(text),2):
        c1=ord(text[i])-65
        c2=ord(text[i+1])-65


        p1=(inv_key[0][0]*c1+inv_key[0][1]*c2)%26
        p2=(inv_key[1][0]*c1+inv_key[1][1]*c2)%26


        plain+=chr(p1+65)
        plain+=chr(p2+65)

    return plain
    
print("Enter the 2x2 matrix ")

a=int(input("Enter the a11:"))
b=int(input("Enter the a12:"))
c=int(input("Enter the a21:"))
d=int(input("Enter the a22:"))

key=[[a,b],[c,d]]

text=input("Enter the TExt to encrypt : ")

print("The Encrypted Text is :", encrypt(text,key))

print("The Decrypted Text is :", decrypt(encrypt(text,key),key))"""


def modular_inverse(a):
    a=a%26
    for i in range(26):
        if (a*i)%26==1:
            return i
    return -1
def encrypt(text,key):
    text=text.upper().replace(" ","")
    cipher=""
    if len(text)%2!=0:
        text+="X"
    for i in range(0,len(text),2):
        p1=ord(text[i])-65
        p2=ord(text[i+1])-65

        c1=(key[0][0]*p1+key[0][1]*p2)%26
        c2=(key[1][0]*p1+key[1][1]*p2)%26

        cipher+=chr(c1+65)
        cipher+=chr(c2+65)

    return cipher


def decrypt(text,key):
    det=(key[0][0]*key[1][1]-key[0][1]*key[1][0])

    inv_det=modular_inverse(det)

    if inv_det ==-1:
        print("Det has no inverse ")
        return ""
    inv_key=[[(key[1][1]*inv_det)%26,(-key[0][1]*inv_det)%26],[(-key[1][0]*inv_det)%26,(key[0][0]*inv_det)%26]]

    cipher=""
    for i in range(0,len(text),2):
        p1=ord(text[i])-65
        p2=ord(text[i+1])-65
    
        c1=(inv_key[0][0]*p1+inv_key[0][1]*p2)%26
        c2=(inv_key[1][0]*p1+inv_key[1][1]*p2)%26
    
        cipher+=chr(c1+65)
        cipher+=chr(c2+65)
    
    return cipher




print("Enter the 2 x2 key Matrix : ")
a=int(input("Enter a11 : "))
b=int(input("Enter a12 : "))
c=int(input("Enter a21 : "))
d=int(input("Enter a22 : "))

key=[[a,b],[c,d]]

text=input("Enter the text message : ")

cipher=encrypt(text,key)
print(cipher)

print(decrypt(cipher,key))