import hashlib
from Crypto.Hash import MD5
def md5(message):
    data=message.encode()
    digest=hashlib.md5(data).hexdigest()
    return digest


def md5_file():
    filename=input("Enter the file name  : ")

    with open(filename,"rb+") as file:
        data=file.read()

    print("The data of the file area : \n",data)
    print( "The file digest is  : ", MD5.new(data).hexdigest(),len(MD5.new(data).hexdigest()))

def avalance():
    message=input("Enter the message : ")

    position=int(input("Enter the positing u want to change : "))

    new_char=input("Enter the new Charather : ")

    new_message=message[:position-1]+new_char+message[position:]
    print(new_message)
    oh=md5(message)
    nh=md5(new_message)

    print("Original Hash \n",oh)
    print("New hash : \n",nh)

    count=sum(bin(int(a,16)^int(b,16)).count('1') for a,b in zip(oh,nh))

    print("Number of bits different : ", count )

md5_file()