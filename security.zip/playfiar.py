"""def key_matrix(key):
    key = key.upper().replace("J", "I")
    letters = ""

    for ch in key:
        if ch not in letters:
            letters += ch

    for ch in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if ch not in letters:
            letters += ch

    matrix = []
    k = 0
    for i in range(5):
        row = []
        for j in range(5):
            row.append(letters[k])
            k += 1
        matrix.append(row)

    return matrix


def position(matrix, ch):
    if ch == "J":
        ch = "I"
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == ch:
                return i, j


def prepare(text):
    text = text.upper().replace("J", "I").replace(" ", "")
    result = ""
    i = 0

    while i < len(text):
        a = text[i]

        if i == len(text) - 1:
            result += a + "X"
            break

        b = text[i + 1]

        if a == b:
            result += a + "X"
            i += 1
        else:
            result += a + b
            i += 2

    return result


def encrypt(text, matrix):
    text = prepare(text)
    cipher = ""

    for i in range(0, len(text), 2):
        a = text[i]
        b = text[i + 1]

        r1, c1 = position(matrix, a)
        r2, c2 = position(matrix, b)

        if r1 == r2:
            cipher += matrix[r1][(c1 + 1) % 5]
            cipher += matrix[r2][(c2 + 1) % 5]

        elif c1 == c2:
            cipher += matrix[(r1 + 1) % 5][c1]
            cipher += matrix[(r2 + 1) % 5][c2]

        else:
            cipher += matrix[r1][c2]
            cipher += matrix[r2][c1]

    return cipher


def decrypt(text, matrix):
    plain = ""

    for i in range(0, len(text), 2):
        a = text[i]
        b = text[i + 1]

        r1, c1 = position(matrix, a)
        r2, c2 = position(matrix, b)

        if r1 == r2:
            plain += matrix[r1][(c1 - 1) % 5]
            plain += matrix[r2][(c2 - 1) % 5]

        elif c1 == c2:
            plain += matrix[(r1 - 1) % 5][c1]
            plain += matrix[(r2 - 1) % 5][c2]

        else:
            plain += matrix[r1][c2]
            plain += matrix[r2][c1]

    return plain


# Main Program
key = input("Enter Key: ")
matrix = key_matrix(key)

print("\nKey Matrix:")
for row in matrix:
    print(*row)

text = input("\nEnter Plain Text: ")

cipher = encrypt(text, matrix)
print("Encrypted Text:", cipher)

plain = decrypt(cipher, matrix)
print("Decrypted Text:", plain)




def key_matrix(key):
    key=key.upper().replace("J","I")
    letters=""

    for ch in key:
        if ch not in letters :
            letters+=ch

    for ch in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if ch not in letters:
            letters+=ch

    matrix=[]
    k=0
    for i in range(5):
        row=[]
        for j in range(5):
            row.append(letters[k])
            k+=1
        matrix.append(row)

    return matrix



def process(text):
    text=text.upper().replace("J","I").replace(" ","")

    result=""

    i=0
    while i<len(text):
        a=text[i]
        if i==len(text)-1:
            result+=a+"X"
            break
        b=text[i+1]

        if a==b:
            result+=a+"X"
            i+=1
        else:
            result+=a+b
            i+=2
    return result 


def position(matrix,ch):
    if ch=="J":
        ch="I"

    for i in range(5):
        for j in range(5):
            if matrix[i][j]==ch:
                return i,j

def encrypt(text,matrix):
    text=process(text)
    cipher=""

    for i in range(0,len(text),2):
        a=text[i]
        b=text[i+1]

        r1,c1=position(matrix,a)
        r2,c2=position(matrix,b)


        if r1==r2:
            cipher+=matrix[r1][(c1+1)%5]
            cipher+=matrix[r2][(c2+1)%5]

        elif c1==c2:
            cipher+=matrix[(r1+1)%5][c1]
            cipher+=matrix[(r2+1)%5][c2]

        else:
            cipher+=matrix[r1][c2]
            cipher+=matrix[r2][c1]

    return cipher


def decrypt(text,matrix):
    plain=""

    for i in range(0,len(text),2):
        a=text[i]
        b=text[i+1]

        r1,c1=position(matrix,a)
        r2,c2=position(matrix,b)
        
        
        if r1==r2:
            plain+=matrix[r1][(c1-1)%5]
            plain+=matrix[r2][(c2-1)%5]
        
        elif c1==c2:
            plain+=matrix[(r1-1)%5][c1]
            plain+=matrix[(r2-1)%5][c2]
        
        else:
            plain+=matrix[r1][c2]
            plain+=matrix[r2][c1]


    return plain



key=input("Enter the key : ")
matrix=key_matrix(key)


for row in matrix:
    print(*row)
text=input("Enter the text to encrypt: ")
print("Encrypted text is : ",encrypt(text,matrix))


tt=input("Enter the text to Decrypt : ")
print("Decryoted Text is : ",decrypt(tt,matrix))


"""




def key_matrix(key):
    key=key.upper().replace("J","I")
    letters=""
    for ch in key:
        if ch not in letters:
            letters+=ch
    for ch in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if ch not in letters:
            letters+=ch

    matrix=[]
    k=0
    for i in range(5):
        row=[]
        for j in range(5):
            row.append(letters[k])
            k+=1
        matrix.append(row)

    return matrix

def prepare(text):
    text=text.upper().replace("J","I").replace(" ","")
    result=""
    i=0
    while i < len(text):
        a=text[i]

        if i==len(text)-1:
            result+=a+"X"
            break
        b=text[i+1]

        if a==b:
            result+=a+"X"
            i+=1
        else:
            result+=a+b
            i+=2
    return result

def position(matrix,ch):
    if ch=="J":
        ch="I"
    for i in range(5):
        for j in range(5):
            if matrix[i][j]==ch:
                return i,j

def encrypt(text,matrix):
    text=prepare(text)
    cipher=""

    for i in range(0,len(text),2):
        a=text[i]
        b=text[i+1]

        r1,c1=position(matrix,a)
        r2,c2=position(matrix,b)

        if r1==r2:
            cipher+=matrix[r1][(c1+1)%5]
            cipher+=matrix[r2][(c2+1)%5]

        elif c1==c2:
            cipher+=matrix[(r1+1)%5][c1]
            cipher+=matrix[(r2+1)%5][c2]

        else:
            cipher+=matrix[r1][c2]
            cipher+=matrix[r2][c1]

    return cipher
def decrypt(text,matrix):
    cipher=""

    for i in range(0,len(text),2):
        a=text[i]
        b=text[i+1]

        r1,c1=position(matrix,a)
        r2,c2=position(matrix,b)

        if r1==r2:
            cipher+=matrix[r1][(c1-1)%5]
            cipher+=matrix[r2][(c2-1)%5]

        elif c1==c2:
            cipher+=matrix[(r1-1)%5][c1]
            cipher+=matrix[(r2-1)%5][c2]

        else:
            cipher+=matrix[r1][c2]
            cipher+=matrix[r2][c1]

    return cipher



key=input("Enter the key : ")
matrix=key_matrix(key)

for row in matrix:
    print(*row)
text=input("Enter the message : ")

cipher=encrypt(text,matrix)
print("Cipher text : ",cipher)

print("Decrypted text : ",decrypt(cipher,matrix))