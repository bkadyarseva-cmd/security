

"""



import math

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(row))


# ---------------- Row Major ----------------
def row_encrypt(text, cols):
    rows = math.ceil(len(text) / cols)

    matrix = [["X" for j in range(cols)] for i in range(rows)]

    k = 0
    for j in range(cols):
        for i in range(rows):
            if k < len(text):
                matrix[i][j] = text[k]
                k += 1

    print("\nRow Major Matrix:")
    print_matrix(matrix)

    cipher = ""
    for i in range(rows):
        for j in range(cols):
            cipher += matrix[i][j]

    return cipher


def row_decrypt(cipher, cols):
    rows = math.ceil(len(cipher) / cols)

    matrix = [["" for j in range(cols)] for i in range(rows)]

    k = 0
    for i in range(rows):
        for j in range(cols):
            matrix[i][j] = cipher[k]
            k += 1

    plain = ""
    for j in range(cols):
        for i in range(rows):
            plain += matrix[i][j]

    return plain.rstrip("X")


# ---------------- Column Major ----------------
def column_encrypt(text, cols):
    rows = math.ceil(len(text) / cols)

    matrix = [["X" for j in range(cols)] for i in range(rows)]

    k = 0
    for i in range(rows):
        for j in range(cols):
            if k < len(text):
                matrix[i][j] = text[k]
                k += 1

    print("\nColumn Major Matrix:")
    print_matrix(matrix)

    cipher = ""
    for j in range(cols):
        for i in range(rows):
            cipher += matrix[i][j]

    return cipher


def column_decrypt(cipher, cols):
    rows = math.ceil(len(cipher) / cols)

    matrix = [["" for j in range(cols)] for i in range(rows)]

    k = 0
    for j in range(cols):
        for i in range(rows):
            matrix[i][j] = cipher[k]
            k += 1

    plain = ""
    for i in range(rows):
        for j in range(cols):
            plain += matrix[i][j]

    return plain.rstrip("X")


# ---------------- Main ----------------
text = input("Enter Plaintext: ").replace(" ", "").upper()
cols = int(input("Enter Number of Columns: "))

row_cipher = row_encrypt(text, cols)
print("Row Major Cipher:", row_cipher)
print("Row Major Decrypted:", row_decrypt(row_cipher, cols))

column_cipher = column_encrypt(text, cols)
print("Column Major Cipher:", column_cipher)
print("Column Major Decrypted:", column_decrypt(column_cipher, cols))




import math 


def encrypt(text,cols):
    rows=math.ceil(len(text)/cols)

    matrix=[["X" for j in range(cols)] for i in range(rows)]

    k=0

    for j in range(cols):
        for i in range(rows):
            if k<len(text):
                matrix[i][j]=text[k]
                k+=1

    print("The row major Matrix is : ")
    for r in matrix:
        print(*r)


    cipher=""

    for i in range(rows):
        for j in range(cols):
            cipher+=matrix[i][j]

    return cipher


def decrypt(text,cols):
    rows=math.ceil(len(text)/cols)
    matrix=[["" for j in range(cols)] for i in range(rows)]
    plain=""

    k=0
    for i in range(rows):
        for j in range(cols):
            matrix[i][j]=text[k]
            k+=1

    for j in range(cols):
        for i in range(rows):
            plain+=matrix[i][j]

    return plain




def col_encrypt(text,cols):

    rows=math.ceil(len(text)/cols)

    matrix=[["X" for j in range(cols)] for i in range(rows)]

    k=0
    for i in range(rows):
            for j in range(cols):
                if k<len(text): 
                    matrix[i][j]=text[k]
                    k+=1

    print("The row major Matrix is : ")
    for r in matrix:
        print(*r)



    cipher=""
    for j in range(cols):
        for i in range(rows):
            cipher +=matrix[i][j]
    
    return cipher


def col_decrypt(text,cols):
    rows=math.ceil(len(text)/cols)
    matrix=[["" for j in range(cols)] for i in range(rows)]
    plain=""

    k=0
    for j in range(cols):
            for i in range(rows):
                    matrix[i][j]=text[k]
                    k+=1
    
        
    
    
    plain=""
    
    for i in range(rows):
        for j in range(cols):
            plain+=matrix[i][j]
    
    return plain.rstrip("X")





text=input("Enter the Text to Encrypt : ").replace(" ","").upper()
cols=int(input("Enter the number of columns : "))


cipher=col_encrypt(text,cols)
print("The encrypted Text is : ",cipher)
print("Decryoted text : ",col_decrypt(cipher,cols).rstrip("X"))


"""


import math 


def encrypt(text,cols):
    rows=math.ceil(len(text)/cols)
    k=0
    matrix=[["X" for j in range(cols)] for i in range(rows)]

    for j in range(cols):
        for i in range(rows):
            if k< len(text):
                matrix[i][j]=text[k]
                k+=1
    print("Row major matrix :")
    for row in matrix:
        print(*row)

    cipher=""
    for i in range(rows):
        for j in range(cols):
            cipher+=matrix[i][j]

    return cipher

def decrypt(text,cols):
    rows=math.ceil(len(text)/cols)
    k=0
    matrix=[["" for j in range(cols)] for i in range(rows)]

    for i in range(rows):
        for j in range(cols):
            matrix[i][j]=text[k]
            k+=1

    plain=""
    for j in range(cols):
        for i in range(rows):
            plain+=matrix[i][j]

    return plain.rstrip("X")
 


text=input("Enter the text  : ").upper().replace(" ","")
cols=int(input("Enter the number of cols : "))

cipher=encrypt(text,cols)


print("Cipjer : ",cipher)
print(decrypt(cipher,cols))