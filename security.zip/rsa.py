"""
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

text = input("Enter Plaintext: ")

key = RSA.generate(2048)

public_key = key.publickey()
private_key = key

cipher = PKCS1_OAEP.new(public_key)

ciphertext = cipher.encrypt(text.encode())

print("Plaintext :", text)
print("Ciphertext (Hex):", ciphertext.hex())

cipher = PKCS1_OAEP.new(private_key)

plain = cipher.decrypt(ciphertext)

print("Decrypted Text:", plain.decode())





from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

text=input("Enter the text to Encrypt : ")

key=RSA.generate(2048)

pub_key=key.public_key()

print("The Gerenated keys : ")
print("private key : ",key.export_key().decode())
print("pub key : ",pub_key.export_key().decode())


cipher=PKCS1_OAEP.new(pub_key)
ct=cipher.encrypt(text.encode())

print("ctext : ",ct.hex())


cipher=PKCS1_OAEP.new(key)
print("de text : ",cipher.decrypt(ct).decode())
"""

from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA,DSA

pvtkey=RSA.generate(2048)
pub_kye=pvtkey.publickey()

cm=PKCS1_OAEP.new(pub_kye)

text=input("Enter the text  : ")
print("Pvt key : ",pvtkey.export_key().decode())
print("Pub key : ",pub_kye.export_key().decode())

cipher=cm.encrypt(text.encode())
print("Cipher text  : ",cipher.hex())

cm=PKCS1_OAEP.new(pvtkey)

print(cm.decrypt(cipher).decode())