"""import math
def prime(a):
    if a<2:
        return False 

    for i in range(2,int(math.sqrt(a))+1):
        if a%i==0:
            return False

    return True

def isvalid(p,q,e):
    if not  prime(p) or  not prime(q):
        return False



    if p==q:
        return False 

    phi=(p-1)*(q-1)
    if e<=1 or e>=phi :
        return False

    
    phi=(p-1)*(q-1)

    if math.gcd(e,phi) !=1:
        return False

    return True 



def calc_d(e,phi):
    for d in range(phi):
        if (e*d) %phi ==1:
            return d



p=61
q=53
e=17
m=88
if isvalid(p,q,e):
    n=p*q
    phi=(p-1)*(q-1)
    d=calc_d(e,phi)
    print("n = ",n)
    print("Phi(n) =", phi)
    print("Pub key : ",(e,n))
    print("Private ey : ",(d,n))

    print("Encrpted text : ")
    c=pow(m,e,n)
    print(c)


    print("decrypted text : ")
    de=pow(c,d,n)
    print(de)

else:
    print("invalid")

"""

import math 

def prime(a):
    if a<2:
        return False 
    for i in range(2,int(math.sqrt(a))+1):
        if a%i==0:
            return False
    return True 
def valid(p,q,e):
    if not prime(p) or not prime(q):
        return False
    if p==q:
        return False

    phi=(p-1)*(q-1)

    if math.gcd(e,phi)!=1:
        return False 

    if e<=1 or e>=phi:
        return False 

    return True 

def calc_d(e,phi):
    for d in range(phi):
        if (e*d)%phi ==1:
            return d

p=61
q=53
e=17
m=88

if valid(p,q,e):
    n=p*q
    phi=(p-1)*(q-1)
    d=calc_d(e,phi)
    print("Public key  : ",(e,n))
    print("Private key  : ",(d,n))
    c=pow(m,e,n)
    print("Cipher text  : ",c)

    de=pow(c,d,n)
    print("Decryted text = ",de)





