import hashlib
from Crypto.Hash import SHA256

# Function to generate SHA-1 hash
def sha1_hash(message):
    data = message.encode()
    result = hashlib.sha1(data).hexdigest()
    return result


def sha1_crypto(message):
    data=message.encode()
    digest=SHA256.new(data)
    return digest
# Function 1: Display message digest
def generate_digest():
    message = input("Enter the text message: ")

    digest = sha1_hash(message)

    print("\nOriginal Message:", message)
    print("SHA-1 Digest:", digest)
    print("Digest Length:", len(digest), "hexadecimal characters")
    print("Digest Crypto : ",sha1_crypto(message).hexdigest(),len(sha1_crypto(message).hexdigest()))


# Function 2: Demonstrate Avalanche Effect
def avalanche_effect():
    message = input("Enter the original message: ")

    if len(message) == 0:
        print("Message cannot be empty for modification.")
        return

    print("Original Message:", message)

    position = int(input(
        "Enter the character position to modify (1 to "
        + str(len(message)) + "): "
    ))

    if position < 1 or position > len(message):
        print("Invalid character position.")
        return

    new_char = input("Enter the replacement character: ")

    if len(new_char) != 1:
        print("Please enter exactly one character.")
        return

    modified = (
        message[:position - 1]
        + new_char
        + message[position:]
    )

    if modified == message:
        print("The replacement character is unchanged.")
        return

    original_hash = sha1_hash(message)
    modified_hash = sha1_hash(modified)

    print("\nOriginal Message:", message)
    print("Modified Message:", modified)
    print("Original SHA-1:", original_hash)
    print("Modified SHA-1:", modified_hash)

    different_bits = sum(
        bin(int(a, 16) ^ int(b, 16)).count('1')
        for a, b in zip(original_hash, modified_hash)
    )

    print("Number of differing hash bits:", different_bits)
    print("Avalanche Effect: A small input change causes a")
    print("significant change in the hash value.")


# Function 3: Compare two messages
def compare_messages():
    message1 = input("Enter the first message: ")
    message2 = input("Enter the second message: ")

    hash1 = sha1_hash(message1)
    hash2 = sha1_hash(message2)

    print("\nFirst Message:", message1)
    print("First SHA-1:", hash1)

    print("\nSecond Message:", message2)
    print("Second SHA-1:", hash2)

    if hash1 == hash2:
        print("\nThe message digests are identical.")
        if message1 == message2:
            print("The messages are identical.")
        else:
            print("The messages differ, but their hashes match.")
    else:
        print("\nThe message digests are different.")
        print("The messages are different.")


# Function 4: Demonstrate SHA-1 preprocessing
def preprocessing():
    message = input("Enter a sentence: ")

    # Convert the message to binary
    data = message.encode('utf-8')
    binary_message = ''.join(format(byte, '08b') for byte in data)

    # Original message length in bits
    original_length = len(binary_message)

    # Append one '1' bit
    padded_message = binary_message + '1'

    # Append zero bits until length is 448 modulo 512
    while len(padded_message) % 512 != 448:
        padded_message += '0'

    # Append the original length as a 64-bit binary number
    length_binary = format(original_length, '064b')
    padded_message += length_binary

    print("\nOriginal Message:", message)
    print("Original Message in Binary:")
    print(binary_message)

    print("\nOriginal Length:", original_length, "bits")
    print("64-bit Length Representation:")
    print(length_binary)

    print("\nPadded Message:")
    print(padded_message)

    print("\nTotal Padded Length:", len(padded_message), "bits")

    # Display the padded message in 512-bit blocks
    total_blocks = len(padded_message) // 512

    print("\nNumber of 512-bit Blocks:", total_blocks)

    for i in range(total_blocks):
        block = padded_message[i * 512:(i + 1) * 512]
        print("\nBlock", i + 1, "(512 bits):")
        print(block)

    print("\nSHA-1 Digest of Original Message:")
    print(sha1_hash(message))


# Main menu
def main():
    while True:
        print("\n========== SHA-1 MENU ==========")
        print("1. Generate SHA-1 Message Digest")
        print("2. Demonstrate Avalanche Effect")
        print("3. Compare Two Messages")
        print("4. Demonstrate SHA-1 Preprocessing")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == '1':
            generate_digest()
            

        elif choice == '2':
            avalanche_effect()

        elif choice == '3':
            compare_messages()

        elif choice == '4':
            preprocessing()

        elif choice == '5':
            print("Program terminated.")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 5.")


if __name__ == "__main__":
    main()
    """



import hashlib

def hash_msg(message):
    data=message.encode()
    digest=hashlib.sha1(data).hexdigest()

    return digest 




def avalanche_effect():

    message=input("Enter the message : ")
    position=int(input("Enter the position u want to change  : "))
    new_char=input("Enter the new characther : ")

    new_message= message[:position-1]+new_char+message[position: ]

    origiginal_d=hash_msg(message)
    new_msg_d=hash_msg(new_message)
    print(message)
    print(new_message)
    print(origiginal_d)
    print(new_msg_d)

    count=sum(bin(int(a,16)^int(b,16)).count('1') for a,b in zip(origiginal_d,new_msg_d ))

    print(count)





def show():
    message=input("Enter the sentence : ")

    message_binary="".join(format(byte,'08b') for byte in message.encode() )
    print("Binary original message \n: ",message_binary )

    original_length=len(message_binary)

    padded_msg=message_binary+'1'

    while len(padded_msg)%512 != 448:
        padded_msg+='0'


    padded_len=format(original_length,'064b')

    padded_msg+=padded_len

    total_blocks=len(padded_msg) //512 

    for i in range(total_blocks):
        print(f"Block i : {i+1} = {padded_msg[i*512:(i+1)*512]}")

    print(hash_msg(message))

show()

"""