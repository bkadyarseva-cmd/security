"""print ("Diffe Helman Key exchange ")

p=int(input("Enter the Prime Number : "))

g=int(input("Enter the Generator : "))

Ap=int(input("Enter Alice Private Key"))
bp=int(input("Enter Bob  Private Key"))

Apub_key=pow(g,Ap,p)
Bpub_key=pow(g,bp,p)


As=pow(Bpub_key,Ap,p)

Bs=pow(Apub_key,bp,p)

print(As,Bs)kugku"""